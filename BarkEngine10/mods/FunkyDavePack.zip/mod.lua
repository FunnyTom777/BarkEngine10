alert("Funky Dave Pack", "Funky Dave Pack has been installed successfully!")

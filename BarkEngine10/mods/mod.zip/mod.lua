open_window("Hello from My Cool Mod!")
